import React, {  Suspense } from 'react';
import '../../App.css';
import Card from '../Cards';


function Anasayfa() {
  return (
    <div className='cards'>
      <Card />
    </div>
  );
}

export default Anasayfa;
