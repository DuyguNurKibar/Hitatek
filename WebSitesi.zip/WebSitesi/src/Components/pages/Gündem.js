import '../../App.css';
import  NewsList  from './NewsList'

function Gündem() {
  return (
    <div className="App">
      <NewsList />
    </div>
  );
}

export default Gündem;

