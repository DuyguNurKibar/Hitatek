import React from 'react';

function Card1({ article }) {
  return (
    <div className="card">
      <img src={article.imageUrl} alt={article.title} />
      <h3>{article.title}</h3>
      <p>{article.description}</p>
    </div>
  );
}

export default Card1;
