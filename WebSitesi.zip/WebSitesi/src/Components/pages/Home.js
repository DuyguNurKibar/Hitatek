import React from 'react';
import '../../App.js';
import HeroSection from '../HeroSection.js';
import Footer from '../Footer.js';


function Anasayfa() {
  return (
    <>
    <HeroSection />
    <Footer />
    </>
  );
}

export default Anasayfa;
